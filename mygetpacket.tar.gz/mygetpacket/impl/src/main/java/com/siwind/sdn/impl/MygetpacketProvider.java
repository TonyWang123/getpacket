/*
 * Copyright © 2015 siwind,Inc. and others.  All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package com.siwind.sdn.impl;

import org.opendaylight.controller.sal.binding.api.BindingAwareBroker.ProviderContext;
import org.opendaylight.controller.sal.binding.api.BindingAwareProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.opendaylight.controller.sal.binding.api.NotificationService;
import org.opendaylight.yangtools.concepts.ListenerRegistration;
import org.opendaylight.yangtools.yang.binding.NotificationListener;

public class MygetpacketProvider implements BindingAwareProvider, AutoCloseable {

    private static final Logger LOG = LoggerFactory.getLogger(MygetpacketProvider.class);

    private NotificationService notificatonService = null;

    // registration for PacketProcessingListener
    private ListenerRegistration<NotificationListener> registration = null;

    @Override
    public void onSessionInitiated(ProviderContext session) {
        LOG.info("MygetpacketProvider Session Initiated");

        notificatonService = session.getSALService(NotificationService.class);

        PacketReceivedHandler handler = new PacketReceivedHandler();
        registration = notificatonService.registerNotificationListener(handler);

    }

    @Override
    public void close() throws Exception {
        LOG.info("MygetpacketProvider Closed");

        if( registration != null ){
            LOG.info("Mygetpacket registration closed.");
            registration.close();
        }

    }

}
