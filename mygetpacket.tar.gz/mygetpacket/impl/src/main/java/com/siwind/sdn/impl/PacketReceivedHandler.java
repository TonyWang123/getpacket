/*
 * Copyright © 2015 siwind,Inc. and others.  All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package com.siwind.sdn.impl;

import org.opendaylight.yang.gen.v1.urn.opendaylight.packet.service.rev130709.PacketProcessingListener;
import org.opendaylight.yang.gen.v1.urn.opendaylight.packet.service.rev130709.PacketReceived;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PacketReceivedHandler implements PacketProcessingListener{

    private static final Logger LOG = LoggerFactory.getLogger(PacketReceivedHandler.class);

    public PacketReceivedHandler(){
        LOG.info("[Siwind] PacketReceivedHandler Initiated.");

    }
    @Override
    public void onPacketReceived(PacketReceived notification) {
        // TODO Auto-generated method stub
        LOG.info("[Siwind] Received a packet.");

        String ingress = notification.getIngress().toString();
        String reason = notification.getPacketInReason().toString();

        LOG.info("[Siwind] Received packet , ingress=" + ingress + ", reason="+reason);

    }

}
